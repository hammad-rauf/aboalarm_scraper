from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

import json

class AngelSpider(CrawlSpider):

    name = "aboalarm"


    start_urls = ['https://www.aboalarm.de/api/categories/16/addresses/listing?letter=top']     
                

    def parse(self,response):
        
        response = json.loads(response.text)
        
        for data in response["addresses"]:
        
            yield Request(url=data["url"],callback=self.main_page)
        
    
    def main_page(self,response):
        
        category = "Versicherung"
        
        sub_category = "Haftpflichtversicherung"

        firmename = response.css(".c-teaser__title::text").extract_first().strip()
        
        full_address = response.xpath('//th[contains(text(),"Adresse")]/following-sibling::td/text()').extract()
        
        address = full_address[0]
        
        try:
            city  = full_address[2].split(" ")[1]
            zip  = full_address[2].split(" ")[0]
        except :
            try:
                city  = full_address[3].split(" ")[1]
                zip  = full_address[3].split(" ")[0]
            except :
                city  = full_address[1].split(" ")[1]
                zip  = full_address[1].split(" ")[0]
        
        full_address = " ".join(full_address)
        
        email = response.css(".table tr:nth-child(2) td::text").extract_first()
        
        website = response.css(".table tr:nth-child(3) td a::attr(href)").extract_first()
        
        fax = response.css(".table tr:nth-child(4) td::text").extract_first()
        
        hotline = response.css(".table tr:nth-child(5) td::text").extract_first().strip()
        hotline = hotline.replace("\n","")
        
        
        Weitere_Adressen_name = []
        Weitere_Adressen_link = []

        for data in response.css(".col-12.col-md-8.offset-md-2 p a"):
        
            Weitere_Adressen_names = data.css("::text").extract_first()
            Weitere_Adressen_links = data.css("::attr(href)").extract_first()
            
            if Weitere_Adressen_links and Weitere_Adressen_names:
                Weitere_Adressen_name.append(Weitere_Adressen_names)
                Weitere_Adressen_link.append(Weitere_Adressen_links)
        
        Weitere_Adressen_name = ",".join(Weitere_Adressen_name) 
        Weitere_Adressen_link = ",".join(Weitere_Adressen_link) 
        
        items={
            "category":category,
            "source_url":response.url,
            "sub_category": sub_category,
            "company":firmename,
            "full_address":full_address,
            "address":address,
            "city":city,
            "zip":zip,
            "email":email,
            "website":website,
            "fax":fax,
            "hotline":hotline,
            "Weitere_Adressen_name":Weitere_Adressen_name,
            "Weitere_Adressen_link":Weitere_Adressen_link            
        }
        
        kundennummer_link = response.css(".text-center a:last-child::attr(href)").extract_first()
        
        if kundennummer_link:
           yield Request(url= kundennummer_link,meta={"items":items},callback=self.second_page)
            
    def second_page(self,response):
        
        items = response.meta["items"]
        
        form_field = response.css(".js-letter-contract-data-key::text").extract()
        form_field = ",".join(form_field)
        
        temp = response.css(".body.letter_body textarea::text").extract_first()
        
        try:
            Betreff = temp.split("\r\n\r\n")[0]
            
            Kündigungstext = temp.split("\r\n\r\n")[1]
        except:
            Betreff = temp.split("\n\n")[0]
            
            Kündigungstext = temp.split("\n\n")[1]
        
        items["form_field"] = form_field
        items["subject"] = Betreff
        items["letter_text"] = Kündigungstext
        
        yield items
        
        